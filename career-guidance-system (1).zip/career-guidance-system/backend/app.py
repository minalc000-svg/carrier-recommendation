import os
import json
import re
import urllib.parse
from flask import Flask, jsonify, request, session
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

# Import configuration and database connection helper
from config import Config
from db import get_db_connection
from openai import OpenAI

app = Flask(__name__)
app.secret_key = Config.SECRET_KEY

# Enable CORS for cross-origin requests from frontend
CORS(app, supports_credentials=True, resources={r"/api/*": {"origins": "*"}})

# Initialize OpenRouter Client using OpenRouter API key from Config
openrouter_client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=Config.OPENROUTER_API_KEY,
)

# Static fallback dataset returned if external AI services fail or return invalid JSON
MOCK_COURSES = [
    {
        "title": "Data Science & Machine Learning Bootcamp",
        "provider": "Coursera / DeepLearning.AI",
        "level": "Intermediate",
        "duration": "6 Weeks",
        "description": "Comprehensive course covering Python, pandas, numpy, scikit-learn, and fundamental machine learning algorithms.",
        "key_topics": ["Python", "Pandas", "Scikit-Learn", "Data Analysis"],
        "url": "https://www.coursera.org/search?query=Data%20Science%20Machine%20Learning"
    },
    {
        "title": "Python for Data Science and Computation",
        "provider": "edX / MIT",
        "level": "Beginner to Advanced",
        "duration": "8 Weeks",
        "description": "Learn to analyze data, build predictive models, and implement data science algorithms using Python.",
        "key_topics": ["Python", "Data Visualization", "Statistics", "Machine Learning"],
        "url": "https://www.edx.org/search?q=Python%20Data%20Science"
    },
    {
        "title": "Full Stack Web Development Masterclass",
        "provider": "Udemy",
        "level": "All Levels",
        "duration": "10 Weeks",
        "description": "Build end-to-end web applications using modern frontend frameworks, REST APIs, and backend databases.",
        "key_topics": ["HTML/CSS", "JavaScript", "Node.js", "REST API"],
        "url": "https://www.udemy.com/courses/search/?q=Full%20Stack%20Web%20Development"
    }
]


# -------------------------------------------------------------------
# User Authentication Endpoints
# -------------------------------------------------------------------

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json or {}
    full_name = data.get('full_name')
    email = data.get('email')
    password = data.get('password')

    if not full_name or not email or not password:
        return jsonify({"success": False, "message": "All fields are required"}), 400

    hashed_password = generate_password_hash(password)

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (full_name, email, password_hash) VALUES (%s, %s, %s)",
            (full_name, email, hashed_password)
        )
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({"success": True, "message": "User registered successfully!"}), 201
    except Exception as e:
        return jsonify({"success": False, "message": "Email already exists or DB error"}), 400


@app.route('/api/login', methods=['POST'])
def login():
    data = request.json or {}
    email = data.get('email')
    password = data.get('password')

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['user_name'] = user['full_name']
            return jsonify({
                "success": True,
                "message": "Login successful",
                "user": {
                    "id": user['id'],
                    "full_name": user['full_name'],
                    "email": user['email']
                }
            }), 200
        else:
            return jsonify({"success": False, "message": "Invalid email or password"}), 401
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({"success": True, "message": "Logged out successfully"}), 200


# -------------------------------------------------------------------
# Course & Assessment Endpoints
# -------------------------------------------------------------------

@app.route('/api/courses', methods=['GET'])
def get_courses():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM courses")
        courses = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify({"success": True, "data": courses}), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/assessment/submit', methods=['POST'])
def submit_assessment():
    data = request.json or {}
    
    interest = data.get('interest', '')
    primary_skill = data.get('primary_skill', '')
    career_goal = data.get('career_goal', '')

    query_parts = []
    if interest:
        query_parts.append(interest)
    if primary_skill:
        query_parts.append(primary_skill)
    if career_goal:
        query_parts.append(f"for {career_goal}")

    search_query = " ".join(query_parts) if query_parts else "Software Development"
    encoded_query = urllib.parse.quote(search_query)

    return jsonify({
        "success": True,
        "redirect_page": f"recommendations.html?query={encoded_query}"
    }), 200


# -------------------------------------------------------------------
# AI Services Endpoints (Chatbot, AI Course Search & Real-Time Dashboard)
# -------------------------------------------------------------------

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json or {}
    user_message = data.get('message', '').strip()

    if not user_message:
        return jsonify({"success": False, "message": "Message is required"}), 400

    try:
        completion = openrouter_client.chat.completions.create(
            model="openrouter/auto",
            max_tokens=500,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are CareerPath AI, a friendly and concise career guidance assistant. "
                        "Help answer questions regarding technical learning paths, career suggestions, and courses."
                    )
                },
                {
                    "role": "user",
                    "content": user_message
                }
            ]
        )

        bot_reply = completion.choices[0].message.content
        return jsonify({"success": True, "reply": bot_reply}), 200

    except Exception as e:
        print("OPENROUTER API ERROR:", str(e))
        return jsonify({
            "success": False, 
            "reply": "I'm having trouble connecting to the AI assistant right now. Please try again shortly."
        }), 200


@app.route('/api/courses/search', methods=['POST'])
def search_courses_ai():
    data = request.json or {}
    raw_query = data.get('query', '').strip()
    course_limit = data.get('limit', 8)  # Accepts custom limit or defaults to 8 courses

    if not raw_query:
        return jsonify({"success": False, "message": "Search query is required"}), 400

    try:
        system_prompt = (
            "You are a career guidance API that recommends online courses based on user queries.\n"
            f"Return ONLY a valid raw JSON array containing exactly {course_limit} course objects tailored to the topic requested.\n"
            "Do NOT wrap output in markdown codeblocks (no ```json). Output raw JSON text only.\n\n"
            "JSON Structure for each object:\n"
            "{\n"
            '  "title": "Exact Course Name",\n'
            '  "provider": "Platform or Academy Name (e.g. Coursera, edX, Udemy, Frontend Masters)",\n'
            '  "level": "Beginner | Intermediate | Advanced | All Levels",\n'
            '  "duration": "e.g., 6 Weeks / 40 Hours",\n'
            '  "description": "Short 1-2 sentence description strictly related to query.",\n'
            '  "key_topics": ["Topic1", "Topic2", "Topic3"],\n'
            '  "url": "Direct external URL to the official course or provider search page (e.g., [https://www.coursera.org/search?query=](https://www.coursera.org/search?query=)...)"\n'
            "}"
        )

        completion = openrouter_client.chat.completions.create(
            model="google/gemini-2.0-flash-lite-001",
            max_tokens=2000,
            temperature=0.3,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Find {course_limit} recommended learning courses for: {raw_query}"}
            ]
        )

        raw_response = completion.choices[0].message.content.strip()

        # Clean markdown codeblocks if returned
        if raw_response.startswith("```"):
            lines = raw_response.splitlines()
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].startswith("```"):
                lines = lines[:-1]
            raw_response = "\n".join(lines).strip()

        courses_data = json.loads(raw_response)
        return jsonify({"success": True, "data": courses_data}), 200

    except Exception as e:
        print(f"[AI Course Search Error]: {str(e)}")

        # Clean search terms for query-aware fallback generation
        sanitized_terms = [
            term.strip() for term in re.split(r'[\/&,\s]+', raw_query) 
            if len(term.strip()) > 1 and term.lower() not in ['for', 'and', 'the', 'in', 'of']
        ]
        
        primary_topic = " ".join(sanitized_terms[:3]) if sanitized_terms else "Software Engineering"
        search_encoded = urllib.parse.quote(primary_topic)

        # Extended dynamic fallback catalog (8 courses)
        dynamic_fallback = [
            {
                "title": f"Complete {primary_topic.title()} Bootcamp & Fundamentals",
                "provider": "Coursera / Global Learning",
                "level": "Beginner to Intermediate",
                "duration": "6 Weeks",
                "description": f"Comprehensive introduction to core concepts, tooling, and practical applications in {primary_topic}.",
                "key_topics": sanitized_terms[:4] if sanitized_terms else ["Core Concepts", "Best Practices", "Hands-on Labs"],
                "url": f"https://www.coursera.org/search?query={search_encoded}"
            },
            {
                "title": f"Advanced {primary_topic.title()} & System Architecture",
                "provider": "edX / Industry Professional Network",
                "level": "Intermediate to Advanced",
                "duration": "8 Weeks",
                "description": f"Master complex software patterns, scaling, and production workflows in {primary_topic}.",
                "key_topics": (sanitized_terms[2:6] if len(sanitized_terms) > 2 else sanitized_terms) + ["Architecture", "Deployment"],
                "url": f"https://www.edx.org/search?q={search_encoded}"
            },
            {
                "title": f"Real-World {primary_topic.title()} Projects Masterclass",
                "provider": "Udemy",
                "level": "All Levels",
                "duration": "10 Weeks",
                "description": f"Build full-scale industry projects and strengthen your portfolio in {primary_topic}.",
                "key_topics": ["Project Design", "Testing & QA", "Production Deployment"],
                "url": f"https://www.udemy.com/courses/search/?q={search_encoded}"
            },
            {
                "title": f"Deep Dive into {primary_topic.title()} Engineering Patterns",
                "provider": "Frontend Masters / Pluralsight",
                "level": "Intermediate",
                "duration": "15 Hours",
                "description": f"Understand underlying mechanisms, optimizations, and clean design patterns in {primary_topic}.",
                "key_topics": ["Design Patterns", "Performance Optimization", "Refactoring"],
                "url": f"https://www.google.com/search?q={search_encoded}+course"
            },
            {
                "title": f"{primary_topic.title()} for Developers & Data Engineers",
                "provider": "DataCamp / O'Reilly Online",
                "level": "Beginner to Advanced",
                "duration": "4 Weeks",
                "description": f"Hands-on exercises and interactive coding challenges focused on real-world {primary_topic} tasks.",
                "key_topics": ["Practical Exercises", "Data Handling", "Automation"],
                "url": f"https://www.google.com/search?q={search_encoded}+datacamp"
            },
            {
                "title": f"Production-Ready {primary_topic.title()} Microservices",
                "provider": "Udacity",
                "level": "Advanced",
                "duration": "2 Months",
                "description": f"Build scalable backend services, CI/CD pipelines, and cloud containers around {primary_topic}.",
                "key_topics": ["Microservices", "Docker", "CI/CD"],
                "url": f"https://www.udacity.com/courses/all?search={search_encoded}"
            },
            {
                "title": f"{primary_topic.title()} Certification Training",
                "provider": "Coursera Specialization",
                "level": "Intermediate",
                "duration": "3 Months",
                "description": f"Earn an industry-recognized certificate demonstrating expertise in {primary_topic}.",
                "key_topics": ["Certification Prep", "Capstone Project", "Industry Standards"],
                "url": f"https://www.coursera.org/search?query={search_encoded}"
            },
            {
                "title": f"Practical {primary_topic.title()} Interview Preparation",
                "provider": "Educative.io",
                "level": "All Levels",
                "duration": "20 Hours",
                "description": f"Prepare for technical interviews with structured coding problems and system design cases on {primary_topic}.",
                "key_topics": ["Algorithm Design", "Interview Coding", "System Design"],
                "url": f"https://www.educative.io/search?q={search_encoded}"
            }
        ]

        return jsonify({
            "success": True,
            "data": dynamic_fallback,
            "fallback": True
        }), 200


@app.route('/api/dashboard/insights', methods=['POST'])
def get_dashboard_insights():
    data = request.json or {}
    user_name = session.get('user_name') or data.get('full_name', 'Student')
    interest = data.get('interest', 'Software Development')
    primary_skill = data.get('primary_skill', 'Python')
    career_goal = data.get('career_goal', 'Software Engineer')

    try:
        system_prompt = (
            "You are a career analytics engine. Return ONLY a valid JSON object analyzing a user's career path. "
            "Do NOT include markdown backticks like ```json. "
            "The JSON structure must be:\n"
            "{\n"
            '  "readiness_score": 85,\n'
            '  "status_summary": "Short 1-2 sentence assessment",\n'
            '  "key_strengths": ["Strength 1", "Strength 2"],\n'
            '  "skill_gaps": ["Gap 1", "Gap 2"],\n'
            '  "recommended_next_steps": ["Step 1", "Step 2", "Step 3"]\n'
            "}"
        )

        user_context = (
            f"User Name: {user_name}, Primary Interest: {interest}, "
            f"Primary Skill: {primary_skill}, Target Career Goal: {career_goal}"
        )

        completion = openrouter_client.chat.completions.create(
            model="google/gemini-2.0-flash-lite-001",
            max_tokens=600,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_context}
            ]
        )

        raw_response = completion.choices[0].message.content.strip()

        if raw_response.startswith("```"):
            lines = raw_response.splitlines()
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].startswith("```"):
                lines = lines[:-1]
            raw_response = "\n".join(lines).strip()

        insights = json.loads(raw_response)
        return jsonify({"success": True, "data": insights}), 200

    except Exception as e:
        print(f"[DASHBOARD AI ERROR]: {str(e)}")
        return jsonify({
            "success": True,
            "data": {
                "readiness_score": 75,
                "status_summary": f"Your current focus on {primary_skill} aligns well with target roles in {career_goal}.",
                "key_strengths": [f"Core knowledge in {primary_skill}", f"Alignment with {interest}"],
                "skill_gaps": ["Project Execution", "System Architecture Design"],
                "recommended_next_steps": [
                    "Complete an end-to-end portfolio project",
                    "Practice algorithmic problem solving",
                    "Learn cloud deployment fundamentals"
                ]
            },
            "fallback": True
        }), 200


if __name__ == '__main__':
    print("Starting CareerPath AI Flask Server on http://0.0.0.0:5000...")
    app.run(host='0.0.0.0', port=5000, debug=True)