import os

class Config:
    MYSQL_HOST = os.getenv('MYSQL_HOST', 'localhost')
    MYSQL_USER = os.getenv('MYSQL_USER', 'root')
    MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', 'root')
    MYSQL_DB = os.getenv('MYSQL_DB', 'career_guidance_db')
    SECRET_KEY = os.getenv('SECRET_KEY', 'super_secret_key_123')
    
    OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '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')