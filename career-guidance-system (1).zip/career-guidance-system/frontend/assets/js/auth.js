document.addEventListener('DOMContentLoaded', () => {
  const loginCard = document.getElementById('loginCard');
  const registerCard = document.getElementById('registerCard');
  const showRegister = document.getElementById('showRegister');
  const showLogin = document.getElementById('showLogin');

  if (showRegister && showLogin) {
    showRegister.addEventListener('click', (e) => {
      e.preventDefault();
      loginCard.classList.add('d-none');
      registerCard.classList.remove('d-none');
    });

    showLogin.addEventListener('click', (e) => {
      e.preventDefault();
      registerCard.classList.add('d-none');
      loginCard.classList.remove('d-none');
    });
  }

  // Handle Login
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;

      try {
        const response = await fetch('http://localhost:5000/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });
        const data = await response.json();

        if (data.success) {
          localStorage.setItem('user', JSON.stringify(data.user));
          window.location.href = 'dashboard.html';
        } else {
          alert(data.message || 'Login failed');
        }
      } catch (err) {
        alert('Server error. Ensure Flask backend is running.');
      }
    });
  }

  // Handle Register
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const full_name = document.getElementById('regName').value;
      const email = document.getElementById('regEmail').value;
      const password = document.getElementById('regPassword').value;

      try {
        const response = await fetch('http://localhost:5000/api/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ full_name, email, password })
        });
        const data = await response.json();

        if (data.success) {
          alert('Registration successful! Please log in.');
          registerCard.classList.add('d-none');
          loginCard.classList.remove('d-none');
        } else {
          alert(data.message || 'Registration failed');
        }
      } catch (err) {
        alert('Server error. Ensure Flask backend is running.');
      }
    });
  }
});

// Guard Protected Pages
function protectPage() {
  const user = localStorage.getItem('user');
  const currentPage = window.location.pathname.split('/').pop();
  
  const protectedPages = ['assessment.html', 'recommendations.html', 'roadmaps.html', 'dashboard.html'];

  if (protectedPages.includes(currentPage) && !user) {
    alert('Please log in first to access this feature.');
    window.location.href = 'login.html';
  }
}

function logoutUser() {
  localStorage.removeItem('user');
  window.location.href = 'login.html';
}

protectPage();