document.addEventListener('DOMContentLoaded', () => {
  // Inject Header
  const headerContainer = document.getElementById('header-container');
  if (headerContainer) {
    fetch('includes/header.html')
      .then(response => response.text())
      .then(data => {
        headerContainer.innerHTML = data;
        highlightActiveNavLink();
        updateNavAuth();
      })
      .catch(err => console.error('Error loading header:', err));
  }

  // Inject Footer & Initialize Floating Chatbot
  const footerContainer = document.getElementById('footer-container');
  if (footerContainer) {
    fetch('includes/footer.html')
      .then(response => response.text())
      .then(data => {
        footerContainer.innerHTML = data;
        // Setup AI chatbot script after footer is loaded
        setupChatbot();
      })
      .catch(err => console.error('Error loading footer:', err));
  }

  // Initialize Course Search Handler (for recommendations.html)
  setupCourseSearch();
});

function highlightActiveNavLink() {
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    if (link.getAttribute('href') === currentPage) {
      link.classList.add('active');
    }
  });
}

function updateNavAuth() {
  const user = JSON.parse(localStorage.getItem('user'));
  const navAuthContainer = document.getElementById('navAuthContainer');
  
  if (user && navAuthContainer) {
    navAuthContainer.innerHTML = `
      <div class="dropdown">
        <button class="btn btn-outline-light btn-sm dropdown-toggle rounded-pill" type="button" data-bs-toggle="dropdown">
          <i class="bi bi-person-circle me-1"></i> ${user.full_name}
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="dashboard.html">Dashboard</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="#" onclick="logoutUser()">Logout</a></li>
        </ul>
      </div>
    `;
  }
}

// Floating Gemini AI Chatbot Logic
function setupChatbot() {
  const toggleBtn = document.getElementById('chatbot-toggle-btn');
  const closeBtn = document.getElementById('chatbot-close-btn');
  const chatWindow = document.getElementById('chatbot-window');
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const chatMessages = document.getElementById('chat-messages');

  if (!toggleBtn || !chatWindow || !chatForm) return;

  // Toggle Chatbot Visibility
  toggleBtn.addEventListener('click', () => {
    chatWindow.classList.toggle('d-none');
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      chatWindow.classList.add('d-none');
    });
  }

  // Handle Form Submission
  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const message = chatInput.value.trim();
    if (!message) return;

    // Append User Message
    appendMessage(message, 'user');
    chatInput.value = '';

    // Show Loading Indicator
    const loadingId = appendLoading();

    try {
      const response = await fetch('http://localhost:5000/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message })
      });

      const data = await response.json();
      removeLoading(loadingId);

      if (data.success) {
        appendMessage(data.reply, 'bot');
      } else {
        appendMessage(data.reply || 'An error occurred while getting response.', 'bot');
      }
    } catch (err) {
      removeLoading(loadingId);
      appendMessage('Unable to reach server. Please ensure Flask backend is running.', 'bot');
    }
  });

  function appendMessage(text, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.classList.add('chat-message', `${sender}-message`, 'mb-3');
    
    const bubble = document.createElement('div');
    bubble.classList.add('p-2', 'px-3', 'rounded-3', 'shadow-sm', 'd-inline-block', 'small');
    if (sender === 'bot') {
      bubble.classList.add('bg-white', 'border', 'text-dark');
    } else {
      bubble.classList.add('bg-primary', 'text-white');
    }
    
    bubble.innerText = text;
    msgDiv.appendChild(bubble);
    chatMessages.appendChild(msgDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function appendLoading() {
    const id = 'loading-' + Date.now();
    const msgDiv = document.createElement('div');
    msgDiv.id = id;
    msgDiv.classList.add('chat-message', 'bot-message', 'mb-3');
    msgDiv.innerHTML = `
      <div class="bg-white p-2 px-3 rounded-3 shadow-sm d-inline-block border text-muted small">
        <span class="spinner-border spinner-border-sm me-1" role="status"></span> Thinking...
      </div>
    `;
    chatMessages.appendChild(msgDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    return id;
  }

  function removeLoading(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  }
}

// Course Search Handler (Integrates Search Form on recommendations.html)
function setupCourseSearch() {
  const searchForm = document.getElementById('courseSearchForm');
  const searchInput = document.getElementById('courseSearchInput');
  const coursesGrid = document.getElementById('coursesGrid');
  const loadingSpinner = document.getElementById('courseSearchLoading');

  if (!searchForm || !coursesGrid) return;

  searchForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (!query) return;

    // Clear existing results and display loader
    coursesGrid.innerHTML = '';
    if (loadingSpinner) loadingSpinner.classList.remove('d-none');

    try {
      const response = await fetch('http://localhost:5000/api/courses/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });

      const data = await response.json();
      if (loadingSpinner) loadingSpinner.classList.add('d-none');

      if (data.success && data.data.length > 0) {
        renderSearchResults(data.data, coursesGrid);
      } else {
        coursesGrid.innerHTML = `
          <div class="col-12 text-center text-muted py-5">
            <i class="bi bi-search fs-1 text-secondary d-block mb-3"></i>
            <h5>No course recommendations found for "${query}".</h5>
            <p class="small">Try searching for another skill or domain.</p>
          </div>
        `;
      }
    } catch (err) {
      if (loadingSpinner) loadingSpinner.classList.add('d-none');
      console.error('Course search error:', err);
      coursesGrid.innerHTML = `
        <div class="col-12 text-center text-danger py-5">
          <i class="bi bi-exclamation-triangle-fill fs-1 d-block mb-3"></i>
          <h5>Unable to fetch search results.</h5>
          <p class="small">Please verify that your Flask server is running at <code>http://localhost:5000</code>.</p>
        </div>
      `;
    }
  });
}

function renderSearchResults(courses, container) {
  container.innerHTML = courses.map(course => `
    <div class="col-md-6 col-lg-4">
      <div class="card h-100 shadow-sm border-0 rounded-3">
        <div class="card-body d-flex flex-column">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="badge bg-primary-subtle text-primary fw-semibold">${course.provider || 'Coursera / Udemy'}</span>
            <small class="text-muted"><i class="bi bi-clock me-1"></i>${course.duration || 'Self-paced'}</small>
          </div>
          <h5 class="card-title fw-bold text-dark">${course.title}</h5>
          <p class="card-text text-secondary small mb-3">${course.description || 'Gain practical knowledge through guided modules and projects.'}</p>
          <div class="mt-auto d-flex justify-content-between align-items-center pt-3 border-top">
            <span class="badge bg-secondary-subtle text-dark">${course.level || 'All Levels'}</span>
            <a href="${course.url || '#'}" target="_blank" class="btn btn-outline-primary btn-sm rounded-2">View Course</a>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}