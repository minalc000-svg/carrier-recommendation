document.addEventListener('DOMContentLoaded', () => {
  const quizForm = document.getElementById('quizForm');
  if (quizForm) {
    quizForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const formData = new FormData(quizForm);
      const payload = {
        q1: formData.get('q1'),
        q2: formData.get('q2'),
        q3: formData.get('q3')
      };

      const response = await submitAssessmentData(payload);
      if (response.success) {
        window.location.href = response.redirect_page;
      } else {
        alert('Assessment failed to submit.');
      }
    });
  }

  const coursesGrid = document.getElementById('coursesGrid');
  if (coursesGrid) {
    loadCourses();
  }
});

async function loadCourses() {
  const coursesGrid = document.getElementById('coursesGrid');
  const response = await fetchCourses();

  if (response.success && response.data.length > 0) {
    coursesGrid.innerHTML = response.data.map(course => `
      <div class="col-md-4">
        <div class="card h-100 border-0 shadow-sm">
          <div class="card-body">
            <div class="d-flex justify-content-between mb-2">
              <span class="badge bg-primary-subtle text-primary">${course.category}</span>
              <span class="badge bg-success-subtle text-success">${course.match_score}% Match</span>
            </div>
            <h5 class="card-title fw-bold">${course.title}</h5>
            <p class="card-text text-secondary small">${course.description}</p>
          </div>
          <div class="card-footer bg-white border-0 pt-0 pb-3 d-flex justify-content-between align-items-center">
            <small class="text-muted"><i class="bi bi-star-fill text-warning me-1"></i>${course.rating} (${course.provider})</small>
            <button class="btn btn-outline-primary btn-sm rounded-pill">Enroll</button>
          </div>
        </div>
      </div>
    `).join('');
  } else {
    coursesGrid.innerHTML = `<div class="col-12 text-center py-5"><p class="text-danger">Unable to load courses from database. Make sure your MySQL database and Flask server are running.</p></div>`;
  }
}