const API_BASE_URL = 'http://localhost:5000/api';

async function fetchCourses() {
  try {
    const response = await fetch(`${API_BASE_URL}/courses`);
    return await response.json();
  } catch (error) {
    console.error('Error fetching courses:', error);
    return { success: False, error: error.message };
  }
}

async function submitAssessmentData(payload) {
  try {
    const response = await fetch(`${API_BASE_URL}/assessment/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    return await response.json();
  } catch (error) {
    console.error('Error submitting assessment:', error);
    return { success: false, error: error.message };
  }
}